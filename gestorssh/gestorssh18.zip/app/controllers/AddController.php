<?php

class AddController
{

    public function index()
    {
        header('location: /4g.php');
    }

    public function server()
    {
        $nome = $_POST['nome'];
        $tipo = $_POST['tipo'];
        $flag = $_POST['flag'];
        $serverip = $_POST['serverip'];
        $checkuser = $_POST['checkuser'];
        $serverport = $_POST['serverport'];
        $sslport = $_POST['sslport'];

        if (!$_SESSION['login']) :
            header("location: " . LINK . "/4g.php");
        endif;

        $conn = Connection::getConn();

        if (isset($_POST['addserver'])) :

            $sql = $conn->query("SELECT * FROM servidores WHERE Name='$nome'")->fetchColumn();

            if ($sql > 0) :
                echo "<script>
                alert('Já existe um servidor com esse nome !');
                window.location='" . LINK . "/4g.php';
                </script>";
            elseif (empty($nome)) :
                echo "<script>
                alert('Nome não pode ficar vazio !');
                window.location='" . LINK . "/4g.php';
                </script>";

            else :

                $sql = $conn->prepare("INSERT INTO servidores SET Name='$nome', TYPE='$tipo', FLAG='$flag', ServerIP='$serverip', CheckUser='$checkuser', ServerPort='$serverport', SSLPort='$sslport', USER='', PASS=''");
                $sql->execute();

                echo "<script>
                alert('Servidor adicionado com sucesso !');
                window.location='" . LINK . "/4g.php';
                </script>";

            endif;
        else :
            header("location: " . LINK . "/4g.php");
        endif;
    }

    public function payload()
    {
        $nome = $_POST['nome'];
        $flag = $_POST['flag'];
        $payload = $_POST['pay'];
        $sni = $_POST['sni'];
        $tlsip = $_POST['tlsip'];
        $proxyip = $_POST['proxyip'];
        $proxyport = $_POST['proxyport'];
        $info = $_POST['info'];

        $conn = Connection::getConn();

        if (!$_SESSION['login']) :
            header("location: " . LINK . "/4g.php");
        endif;

        $sql = $conn->query("SELECT * FROM payloads WHERE Name='$nome'")->fetchColumn();

        if (isset($_POST['addpay'])) :

            if ($sql > 0) :
                echo "<script>
                alert('Já existe uma payload com esse nome !');
                window.location='" . LINK . "/4g.php';
                </script>";
            elseif (empty($nome)) :
                echo "<script>
                alert('Nome não pode ficar vazio !');
                window.location='" . LINK . "/4g.php';
                </script>";
            else :

                $sql = $conn->prepare("INSERT INTO payloads SET Name='$nome', FLAG='$flag', Payload='$payload', SNI='$sni', TlsIP='$tlsip', ProxyIP='$proxyip', ProxyPort='$proxyport', info='$info'");
                $sql->execute();

                echo "<script>
                alert('Payload adicionada com sucesso !');
                window.location='" . LINK . "/4g.php';
                </script>";

            endif;
        else :
            header("location: " . LINK . "/4g.php");
        endif;
    }


    public function multipayload()
    {
        $texto = $_POST['texto'];
        $adicionados = 0;
        $nao_adicionados = 0;
        $total_inseridas = 0;

        $conn = Connection::getConn();

        if (!$_SESSION['login']) :
            header("location: " . LINK . "/4g.php");
        endif;


        if (empty($texto))
        {
            echo "<script>
            alert('As payloads não podem ficar vazias !');
            window.location='" . LINK . "/app.php';
            </script>";
        }
        else
        {
            $json = '[
            '.$texto.'
            ]
            ';

            $obj = json_decode($json, true);
            $qtd = count($obj);

            if($qtd <= 0)
            {
                echo "<script>
                alert('Erro de syntax nas payloads !');
                window.location='" . LINK . "/app.php';
                </script>";
            }
            else
            {
                for($i=0; $i < $qtd; $i++)
                {
                    $nome = $obj[$i]['Name'];
                    if(empty($nome))
                    {
                        $nao_adicionados++;
                        continue;
                    }

                    $sql = $conn->query("SELECT * FROM payloads WHERE Name='$nome'")->fetchColumn();
                    if ($sql > 0)
                    {
                        $nao_adicionados++;
                        //echo "<h1>TOTAL NÃO ADICIONADO = $nao_adicionados</h1>";
                        continue;
                    }
                    $adicionados++;
                    $flag = $obj[$i]['FLAG'];
                    $payload = $obj[$i]['Payload'];
                    $sni = $obj[$i]['SNI'];
                    $tlsip = $obj[$i]['TlsIP'];
                    $proxyip = $obj[$i]['ProxyIP'];
                    $proxyport = $obj[$i]['ProxyPort'];
                    $info = $obj[$i]['Info'];
                    $conn->query("INSERT INTO payloads SET Name='$nome', FLAG='$flag', Payload='$payload', SNI='$sni', TlsIP='$tlsip', ProxyIP='$proxyip', ProxyPort='$proxyport', Info='$info'");
                }

                // echo "<script>
                // alert('Payloads adicionadas com sucesso !');
                // window.location='" . LINK . "/4g.php';
                // </script>";
                $total_inseridas = $adicionados + $nao_adicionados;
                echo "<script>
                alert('Total de payloads adicionadas: $adicionados. \\nTotal de payloads não adicionadas: $nao_adicionados.\\nTotal de payloads inseridas: $total_inseridas.');
                window.location='" . LINK . "/4g.php';
                </script>";
            }
        }

        #header("location: " . LINK . "/4g.php");
    }    

    public function port()
    {

        $porta = $_POST['porta'];

        $conn = Connection::getConn();

        if (!$_SESSION['login']) :
            header("location: " . LINK . "/4g.php");
        endif;

        if (isset($_POST['addporta'])) :

            $sql = $conn->query("SELECT * FROM portas WHERE Porta='$porta'")->fetchColumn();

            if ($sql > 0) :
                echo "<script>
                alert('Essa porta já existe !');
                window.location='" . LINK . "/4g.php';
                </script>";
            elseif (empty($porta)) :
                echo "<script>
                alert('Porta não pode ficar vazio !');
                window.location='" . LINK . "/4g.php';
                </script>";
            else :

                $sql = $conn->prepare("INSERT INTO portas SET Porta='$porta'");
                $sql->execute();

                echo "<script>
                alert('Porta adicionada com sucesso !');
                window.location='" . LINK . "/4g.php';
                </script>";

            endif;
        else :
            header("location: " . LINK . "/4g.php");
        endif;
    }
}
